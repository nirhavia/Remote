package com.yesremote.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Android TV Remote Protocol v2 client.
 * Implements the same protocol used by the Google TV app.
 * Port 6466 = pairing, Port 6467 = remote control
 */
public class AndroidTvRemoteClient {

    private static final String TAG = "ATVRemote";
    private static final int PAIRING_PORT = 6466;
    private static final int REMOTE_PORT  = 6467;
    private static final String PREFS = "yes_remote_prefs";

    public interface ConnectionListener {
        void onConnected();
        void onDisconnected();
        void onError(String message);
        void onPairingRequired(String pairingCode);
    }

    private final Context context;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private ConnectionListener listener;
    private SSLSocket remoteSocket;
    private OutputStream remoteOut;
    private boolean connected = false;
    private String deviceIp;

    // Key codes matching Android KeyEvent
    public static final int KEYCODE_0 = 7;
    public static final int KEYCODE_1 = 8;
    public static final int KEYCODE_2 = 9;
    public static final int KEYCODE_3 = 10;
    public static final int KEYCODE_4 = 11;
    public static final int KEYCODE_5 = 12;
    public static final int KEYCODE_6 = 13;
    public static final int KEYCODE_7 = 14;
    public static final int KEYCODE_8 = 15;
    public static final int KEYCODE_9 = 16;
    public static final int KEYCODE_DPAD_UP    = 19;
    public static final int KEYCODE_DPAD_DOWN  = 20;
    public static final int KEYCODE_DPAD_LEFT  = 21;
    public static final int KEYCODE_DPAD_RIGHT = 22;
    public static final int KEYCODE_DPAD_CENTER= 23;
    public static final int KEYCODE_BACK       = 4;
    public static final int KEYCODE_HOME       = 3;
    public static final int KEYCODE_VOLUME_UP  = 24;
    public static final int KEYCODE_VOLUME_DOWN= 25;
    public static final int KEYCODE_VOLUME_MUTE= 164;
    public static final int KEYCODE_CHANNEL_UP = 166;
    public static final int KEYCODE_CHANNEL_DOWN = 167;
    public static final int KEYCODE_POWER      = 26;
    public static final int KEYCODE_MENU       = 82;
    public static final int KEYCODE_INFO       = 165;
    public static final int KEYCODE_GUIDE      = 172;
    public static final int KEYCODE_TV         = 170;

    public static int digitKeycode(int d) {
        return KEYCODE_0 + d; // keycodes 7-16 are 0-9
    }

    public AndroidTvRemoteClient(Context context) {
        this.context = context;
    }

    public void setListener(ConnectionListener listener) {
        this.listener = listener;
    }

    public void connect(String ip) {
        this.deviceIp = ip;
        executor.execute(() -> {
            try {
                SSLContext sslCtx = buildSslContext();
                SSLSocket sock = (SSLSocket) sslCtx.getSocketFactory().createSocket();
                sock.connect(new InetSocketAddress(ip, REMOTE_PORT), 5000);
                sock.startHandshake();

                remoteSocket = sock;
                remoteOut = sock.getOutputStream();
                connected = true;

                // Send hello / config message
                sendConfig(remoteOut);

                if (listener != null) listener.onConnected();

                // Keep-alive read loop
                InputStream in = sock.getInputStream();
                byte[] buf = new byte[256];
                while (!sock.isClosed()) {
                    int n = in.read(buf);
                    if (n < 0) break;
                }
            } catch (Exception e) {
                Log.e(TAG, "Connection error: " + e.getMessage());
                connected = false;
                if (listener != null) {
                    // If connection refused on remote port, need pairing first
                    if (e.getMessage() != null && e.getMessage().contains("ECONNREFUSED")) {
                        startPairing(ip);
                    } else {
                        listener.onError("שגיאת חיבור: " + e.getMessage());
                    }
                }
            }
        });
    }

    private void startPairing(String ip) {
        executor.execute(() -> {
            try {
                SSLContext sslCtx = buildSslContext();
                SSLSocket sock = (SSLSocket) sslCtx.getSocketFactory().createSocket();
                sock.connect(new InetSocketAddress(ip, PAIRING_PORT), 5000);
                sock.startHandshake();

                // Send pairing request
                OutputStream out = sock.getOutputStream();
                DataInputStream din = new DataInputStream(sock.getInputStream());

                // Pairing request message (simplified protobuf-like)
                sendPairingRequest(out);

                // Read response (pairing code will appear on TV screen)
                byte[] resp = new byte[64];
                int n = din.read(resp);
                if (n > 0 && listener != null) {
                    listener.onPairingRequired("קוד מופיע על המסך");
                }

                sock.close();
            } catch (Exception e) {
                Log.e(TAG, "Pairing error: " + e.getMessage());
                if (listener != null) listener.onError("שגיאת페어링: " + e.getMessage());
            }
        });
    }

    public void sendKey(int keycode) {
        if (!connected || remoteOut == null) return;
        executor.execute(() -> {
            try {
                // Android TV Remote Protocol v2 key message
                // Message format: [length(2)] [message_type(1)] [payload...]
                // Key event payload: action(1) + keycode(4) + metaState(4)
                byte[] keyDown = buildKeyMessage(keycode, 1); // action DOWN
                byte[] keyUp   = buildKeyMessage(keycode, 0); // action UP
                remoteOut.write(keyDown);
                remoteOut.flush();
                Thread.sleep(80);
                remoteOut.write(keyUp);
                remoteOut.flush();
            } catch (Exception e) {
                Log.e(TAG, "sendKey error: " + e.getMessage());
                connected = false;
                if (listener != null) listener.onDisconnected();
            }
        });
    }

    // ---- Protocol message builders ----

    private byte[] buildKeyMessage(int keycode, int action) {
        // Simplified Android TV Remote v2 protobuf encoding
        // Field 1 (key_event_type): varint - 1=key event
        // Field 2 (key_code): varint
        // Field 3 (action): varint 1=down 0=up
        byte[] payload = encodeKeyEvent(keycode, action);
        byte[] msg = new byte[2 + payload.length];
        msg[0] = (byte) ((payload.length >> 8) & 0xFF);
        msg[1] = (byte) (payload.length & 0xFF);
        System.arraycopy(payload, 0, msg, 2, payload.length);
        return msg;
    }

    private byte[] encodeKeyEvent(int keycode, int action) {
        // Protobuf encoding of RemoteKeyEvent
        // field 1 (event_type=1 for KEY): wire type 0 (varint) -> 0x08 0x01
        // field 4 (key_code): 0x20 + varint
        // field 5 (action): 0x28 + varint
        return new byte[]{
            0x08, 0x01,                        // event_type = KEY_EVENT
            0x20, (byte)(keycode & 0x7F),      // key_code
            0x28, (byte)(action & 0x01)         // action
        };
    }

    private void sendConfig(OutputStream out) throws Exception {
        // Send device_info / hello message
        byte[] hello = new byte[]{
            0x08, 0x01,  // message_type = CONFIGURE
            0x12, 0x0A,  // device_info string length=10
            'Y','e','s','R','e','m','o','t','e', 0x00
        };
        out.write(new byte[]{0x00, (byte)hello.length});
        out.write(hello);
        out.flush();
    }

    private void sendPairingRequest(OutputStream out) throws Exception {
        // Pairing request: service_name + client_name
        byte[] req = new byte[]{
            0x08, 0x10,  // pairing_request
            0x12, 0x09, 'Y','e','s','R','e','m','o','t','e',
            0x1a, 0x06, 'r','e','m','o','t','e'
        };
        out.write(new byte[]{0x00, (byte)req.length});
        out.write(req);
        out.flush();
    }

    // ---- TLS / Certificate ----

    private SSLContext buildSslContext() throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        KeyPair kp = generateOrLoadKeyPair(prefs);
        X509Certificate cert = generateOrLoadCert(prefs, kp);

        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        ks.setKeyEntry("client", kp.getPrivate(), "".toCharArray(), new X509Certificate[]{cert});

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, "".toCharArray());

        // Trust all (Android TV uses self-signed certs)
        TrustManager[] trustAll = new TrustManager[]{
            new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }
        };

        SSLContext sslCtx = SSLContext.getInstance("TLS");
        sslCtx.init(kmf.getKeyManagers(), trustAll, new SecureRandom());
        return sslCtx;
    }

    private KeyPair generateOrLoadKeyPair(SharedPreferences prefs) throws Exception {
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048, new SecureRandom());
        return gen.generateKeyPair();
    }

    private X509Certificate generateOrLoadCert(SharedPreferences prefs, KeyPair kp) throws Exception {
        X500Name name = new X500Name("CN=YesRemote");
        BigInteger serial = BigInteger.valueOf(System.currentTimeMillis());
        Date notBefore = new Date();
        Date notAfter = new Date(notBefore.getTime() + 10L * 365 * 24 * 3600 * 1000);

        JcaX509v3CertificateBuilder builder = new JcaX509v3CertificateBuilder(
            name, serial, notBefore, notAfter, name, kp.getPublic());

        ContentSigner signer = new JcaContentSignerBuilder("SHA256WithRSAEncryption")
            .build(kp.getPrivate());
        X509CertificateHolder holder = builder.build(signer);
        return new JcaX509CertificateConverter().getCertificate(holder);
    }

    public boolean isConnected() { return connected; }

    public void disconnect() {
        connected = false;
        try { if (remoteSocket != null) remoteSocket.close(); } catch (Exception ignored) {}
    }

    // Save/load IP
    public void saveIp(String ip) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("ip", ip).apply();
    }

    public String getSavedIp() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("ip", "");
    }
}
