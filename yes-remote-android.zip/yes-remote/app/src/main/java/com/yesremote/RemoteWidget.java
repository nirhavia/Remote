package com.yesremote;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

import com.yesremote.remote.AndroidTvRemoteClient;

public class RemoteWidget extends AppWidgetProvider {

    private static final int[] DIGIT_BTN_IDS = {
        R.id.w0, R.id.w1, R.id.w2, R.id.w3, R.id.w4,
        R.id.w5, R.id.w6, R.id.w7, R.id.w8, R.id.w9
    };

    private static final int[] DIGIT_KEYCODES = {
        AndroidTvRemoteClient.KEYCODE_0,
        AndroidTvRemoteClient.KEYCODE_1,
        AndroidTvRemoteClient.KEYCODE_2,
        AndroidTvRemoteClient.KEYCODE_3,
        AndroidTvRemoteClient.KEYCODE_4,
        AndroidTvRemoteClient.KEYCODE_5,
        AndroidTvRemoteClient.KEYCODE_6,
        AndroidTvRemoteClient.KEYCODE_7,
        AndroidTvRemoteClient.KEYCODE_8,
        AndroidTvRemoteClient.KEYCODE_9,
    };

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) updateWidget(ctx, mgr, id);
    }

    static void updateWidget(Context ctx, AppWidgetManager mgr, int widgetId) {
        RemoteViews views = new RemoteViews(ctx.getPackageName(), R.layout.widget_remote);

        // Wire digit buttons
        for (int i = 0; i < DIGIT_BTN_IDS.length; i++) {
            views.setOnClickPendingIntent(DIGIT_BTN_IDS[i],
                makeKeyIntent(ctx, DIGIT_KEYCODES[i], widgetId * 20 + i));
        }

        // Wire action buttons
        views.setOnClickPendingIntent(R.id.w_ch_up,    makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_CHANNEL_UP,   widgetId * 20 + 11));
        views.setOnClickPendingIntent(R.id.w_ch_down,  makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_CHANNEL_DOWN, widgetId * 20 + 12));
        views.setOnClickPendingIntent(R.id.w_vol_up,   makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_VOLUME_UP,    widgetId * 20 + 13));
        views.setOnClickPendingIntent(R.id.w_vol_down, makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_VOLUME_DOWN,  widgetId * 20 + 14));
        views.setOnClickPendingIntent(R.id.w_mute,     makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_VOLUME_MUTE,  widgetId * 20 + 15));
        views.setOnClickPendingIntent(R.id.w_ok,       makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_DPAD_CENTER,  widgetId * 20 + 16));
        views.setOnClickPendingIntent(R.id.w_back,     makeKeyIntent(ctx, AndroidTvRemoteClient.KEYCODE_BACK,         widgetId * 20 + 17));

        mgr.updateAppWidget(widgetId, views);
    }

    private static PendingIntent makeKeyIntent(Context ctx, int keycode, int reqCode) {
        Intent i = new Intent(ctx, RemoteService.class);
        i.setAction(RemoteService.ACTION_SEND_KEY);
        i.putExtra(RemoteService.EXTRA_KEYCODE, keycode);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT |
            (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getService(ctx, reqCode, i, flags);
    }
}
