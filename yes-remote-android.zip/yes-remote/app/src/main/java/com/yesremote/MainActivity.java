package com.yesremote;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.yesremote.remote.AndroidTvRemoteClient;

public class MainActivity extends AppCompatActivity {

    private AndroidTvRemoteClient client;
    private TextView tvStatus;
    private EditText etIp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        client = new AndroidTvRemoteClient(this);
        tvStatus = findViewById(R.id.tvStatus);
        etIp = findViewById(R.id.etIp);

        // Load saved IP
        String savedIp = client.getSavedIp();
        if (!savedIp.isEmpty()) etIp.setText(savedIp);

        client.setListener(new AndroidTvRemoteClient.ConnectionListener() {
            @Override public void onConnected() {
                runOnUiThread(() -> {
                    tvStatus.setText("✅ מחובר");
                    tvStatus.setTextColor(0xFF4CAF50);
                });
            }
            @Override public void onDisconnected() {
                runOnUiThread(() -> {
                    tvStatus.setText("❌ מנותק");
                    tvStatus.setTextColor(0xFFE94560);
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    tvStatus.setText("⚠️ " + message);
                    tvStatus.setTextColor(0xFFFF9800);
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                });
            }
            @Override public void onPairingRequired(String code) {
                runOnUiThread(() -> {
                    tvStatus.setText("🔗 נדרש קישור - " + code);
                    Toast.makeText(MainActivity.this,
                        "קוד קישור מופיע על מסך הטלוויזיה - הקלד אותו", Toast.LENGTH_LONG).show();
                });
            }
        });

        setupButtons();

        // Auto-connect if IP saved
        if (!savedIp.isEmpty()) connectToDevice(savedIp);
    }

    private void setupButtons() {
        // Connect button
        Button btnConnect = findViewById(R.id.btnConnect);
        btnConnect.setOnClickListener(v -> {
            String ip = etIp.getText().toString().trim();
            if (ip.isEmpty()) {
                Toast.makeText(this, "הכנס כתובת IP", Toast.LENGTH_SHORT).show();
                return;
            }
            client.saveIp(ip);
            connectToDevice(ip);
        });

        // Digit buttons
        int[] digitIds = {R.id.btn0,R.id.btn1,R.id.btn2,R.id.btn3,R.id.btn4,
                          R.id.btn5,R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9};
        for (int i = 0; i < digitIds.length; i++) {
            final int digit = i;
            Button b = findViewById(digitIds[i]);
            if (b != null) b.setOnClickListener(v -> client.sendKey(AndroidTvRemoteClient.digitKeycode(digit)));
        }

        // Navigation
        bindKey(R.id.btnUp,    AndroidTvRemoteClient.KEYCODE_DPAD_UP);
        bindKey(R.id.btnDown,  AndroidTvRemoteClient.KEYCODE_DPAD_DOWN);
        bindKey(R.id.btnLeft,  AndroidTvRemoteClient.KEYCODE_DPAD_LEFT);
        bindKey(R.id.btnRight, AndroidTvRemoteClient.KEYCODE_DPAD_RIGHT);
        bindKey(R.id.btnOk,    AndroidTvRemoteClient.KEYCODE_DPAD_CENTER);
        bindKey(R.id.btnBack,  AndroidTvRemoteClient.KEYCODE_BACK);
        bindKey(R.id.btnHome,  AndroidTvRemoteClient.KEYCODE_HOME);
        bindKey(R.id.btnMenu,  AndroidTvRemoteClient.KEYCODE_MENU);

        // Media controls
        bindKey(R.id.btnVolUp,   AndroidTvRemoteClient.KEYCODE_VOLUME_UP);
        bindKey(R.id.btnVolDown, AndroidTvRemoteClient.KEYCODE_VOLUME_DOWN);
        bindKey(R.id.btnMute,    AndroidTvRemoteClient.KEYCODE_VOLUME_MUTE);
        bindKey(R.id.btnChUp,    AndroidTvRemoteClient.KEYCODE_CHANNEL_UP);
        bindKey(R.id.btnChDown,  AndroidTvRemoteClient.KEYCODE_CHANNEL_DOWN);
        bindKey(R.id.btnPower,   AndroidTvRemoteClient.KEYCODE_POWER);
        bindKey(R.id.btnInfo,    AndroidTvRemoteClient.KEYCODE_INFO);
        bindKey(R.id.btnGuide,   AndroidTvRemoteClient.KEYCODE_GUIDE);
    }

    private void bindKey(int viewId, int keycode) {
        View v = findViewById(viewId);
        if (v != null) v.setOnClickListener(view -> client.sendKey(keycode));
    }

    private void connectToDevice(String ip) {
        tvStatus.setText("🔄 מתחבר...");
        tvStatus.setTextColor(0xFF8892A4);
        client.connect(ip);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        client.disconnect();
    }
}
